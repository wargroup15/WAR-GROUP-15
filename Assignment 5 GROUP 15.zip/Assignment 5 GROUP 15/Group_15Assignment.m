clear; close('all'); clc;
start_toolkit;
d = epanet('group 15.inp');
d.plot;
d.plot('nodes', 'yes', 'fontsize', 12)
d.plot('links', 'yes', 'fontsize', 12)
d.plot('linksindex', 'yes', 'fontsize',8);
d.plot('nodesindex', 'yes', 'fontsize',14);
d.plot('links', 'yes', 'highlightlink',{'10'}, 'fontsize',8);
d.plot('highlightnode',{'10', '32'});
d.plot('point', 'no');
d.plot('line', 'no');
linkSet1 = d.getLinkNameID(1:4);
colorLinkSet1 = repmat({'r'},1,length(linkSet1));
linkSet2 = d.getLinkNameID([5,6,7,8]);
colorLinkSet2=repmat({'g'},1,length(linkSet2));
d.plot('highlightlink',[linkSet1 linkSet2],'colorlink',[colorLinkSet1 colorLinkSet2])
nodeSet1 = d.getNodeNameID(1:4);
colorLinkSet1 = repmat({'y'},1,length(nodeSet1));
nodeSet2 = d.getNodeNameID([5,6,7,8]);
colorLinkSet2=repmat({'g'},1,length(nodeSet2));
d.plot('highlightnode',[nodeSet1 nodeSet2],'colornode',[colorLinkSet1 colorLinkSet2])
d.plot('legend', 'hide')
d.plot('extend', 'yes')
d.plot('legendposition', 'EastOutside')
h = figure;
d.plot('axes', h)

% Plot for matlab apps (GUIs)
%d.plot('uifigure', app.UIFigure, 'axes', app.UIAxes,'legend','hide');
h = d.plotGraph;
title('Network Graph');
d.plotGraph('nodes', 'yes'); % Show ID of nodes
title('Network Graph with node IDs');
d.unload
